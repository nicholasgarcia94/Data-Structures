Nicholas Garcia JHED: ngarcia5	
Ashwin Bhat JHED: abhat4

We currently have the CList implementation, the cookinItemInterface, 
the CookingStationInteface, and their respective classes working. 
They all compile properly with no error. The issue we are running into 
is in the simulation, it is not circulating through the kitchen as 
intended to so our algorithm is off somewhere. 
We�ve tested extensively trying to resolve this issue. 

There was a NullPOinterException that we finally managed to get rid when 
the simulation was moving through CutthroatKitchen. 

This assignment was very time consuming and we were hindered by the lack of
information at times. We felt like clearer guidelines on the simulation
and creating file outputs would have been helpful, as would more distinct
instructions for tend(). 

